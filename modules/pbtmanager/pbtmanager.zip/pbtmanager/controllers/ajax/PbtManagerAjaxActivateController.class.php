<?php
/**
 * @copyright   &copy; 2005-2026 PHPBoost
 * @license     https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL-3.0
 * @author      LamPDL
 * @version     PHPBoost 6.0 - last update: 2026 03 01
 * @since       PHPBoost 6.0 - 2026 03 01
 */
class PbtManagerAjaxActivateController extends AbstractController
{
    public function execute(HTTPRequestCustom $request)
    {
        if (!PbtManagerAuthorizationsService::check_authorizations()->moderation())
            return new JSONResponse(array('success' => false, 'error' => 'Unauthorized'), 403);

        $module_id = preg_replace('/[^a-zA-Z0-9_\-]/', '', $request->get_string('id', ''));

        if (!ModulesManager::is_module_installed($module_id))
            return new JSONResponse(array('success' => false, 'error' => 'Module non installé'));

        ModulesManager::update_module($module_id, 1);
        return new JSONResponse(array('success' => true));
    }
}
?>
